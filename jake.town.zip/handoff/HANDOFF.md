# jake.town — design handoff for Claude Code

Hey. This is a redesign of [jake.town](https://jake.town) — new visual system across landing, resume, blog index, and post template. Same Jekyll setup, no new dependencies (just two Google Fonts).

This folder has **two copies of the design**:

| Folder | What it is | When to use it |
|---|---|---|
| `preview/` | Standalone HTML files. No Jekyll deps, no Liquid. Open them in a browser directly. | Reference / visual ground truth. Useful for diffing pixel-for-pixel against the Jekyll output. |
| `jekyll/` | Jekyll-templated versions with frontmatter + Liquid. **These are the files to drop into the site.** | The actual integration. |

## TL;DR for Claude Code

1. Copy the files in `jekyll/` into the matching paths inside `jake.town/`. The mapping is 1:1:
    - `jekyll/index.html`              → `jake.town/index.html` (replace)
    - `jekyll/resume.html`             → `jake.town/resume.html` (replace)
    - `jekyll/blog/index.html`         → `jake.town/blog/index.html` (replace)
    - `jekyll/_layouts/home.html`      → `jake.town/_layouts/home.html` (new file)
    - `jekyll/_layouts/resume.html`    → `jake.town/_layouts/resume.html` (replace)
    - `jekyll/_layouts/default.html`   → `jake.town/_layouts/default.html` (replace)
    - `jekyll/_layouts/post.html`      → `jake.town/_layouts/post.html` (replace)
2. Run `bundle exec jekyll serve` and visit `/`, `/resume`, `/blog/`, and any individual post.
3. Compare each against the matching file in `preview/` — they should look the same.
4. See the **Open questions** section at the bottom of this file before merging.

## The visual system

**Vibe**: jake.town is a 24-hour switchboard. Console aesthetic across every page. Dark warm ground, amber glow, dial-tone green for live indicators. Mono fonts for chrome and code, serif for long-form reading, no emoji (one phone in the favicon excepted).

**Type**
- **Newsreader** (Google Fonts) — display + serif body text on the blog. Italic for emphasis.
- **System sans** (`-apple-system, BlinkMacSystemFont, "Helvetica Neue", ...`) — body fallback / UI.
- **JetBrains Mono** (Google Fonts) — chrome, prompts, code, metadata, all the labels.

**Palette** (CSS vars, declared in every layout's `:root`)
```
--bg:         #0f0d09   /* near-black ink, slightly warm */
--bg-soft:    #1a1610   /* card / chrome panel */
--bg-line:    #262017   /* hairlines, borders */
--code-bg:    #0a0805   /* code block ground */
--paper:      #f5f1e8   /* primary text */
--paper-warm: #cfc6b3   /* body text */
--ink-mute:   #7a705f   /* metadata, secondary */
--glow:       #f0a64a   /* primary accent (amber) */
--signal:     #c2410c   /* live / hot */
--green:      #4ade80   /* dial-tone, "connected", prompts */
```

Plus syntax accent colors on the resume's `stacks` block: `#a5e3ff` (keys), `#c8f0a5` (strings).

**Chrome elements** (shared across resume, blog index, blog post)
- macOS-style traffic-light window bar at top: red `#ff5f57` / yellow `#febc2e` / green `#28c840`, with a "jakswa@host ~ /path ─ zellij 0" title.
- A `$ jake --whatever` prompt line just under it.
- `── SECTION ──` dividers with `letter-spacing: 0.22em-0.28em` mono labels in glow color.
- CRT scanlines at 5–7% opacity (`body::before`) — purely decorative, set `pointer-events: none`.

**Landing is the exception**: full-bleed, no max-width, oscilloscope + dial-pad. Uses its own `_layouts/home.html`.

## File-by-file notes

### `_layouts/home.html` + `index.html`
Operator-console landing.

- Full viewport, no scroll on desktop. `min-width: 980px` on `.stage` protects the dial-pad — narrower viewports stack vertically (see the `@media (max-width: 820px)` block).
- The dial-pad is the nav. Each key links to a different destination (resume, blog, github, kincall, marta, linkedin, home server, email, phone).
- The oscilloscope is a live SVG path animated via `requestAnimationFrame`. It responds to cursor Y position — moving your mouse up/down warps the trace. Respects `prefers-reduced-motion` (renders a static waveform).
- Clock is local time **forced to Atlanta** via `timeZone: 'America/New_York'`.
- "Calls / 24h", "Uptime", and "RX/TX/ping" are static decorative values. Replace with real numbers if you want to wire something live.

### `_layouts/resume.html` + `resume.html`
Console resume. Long, scrollable.

- Each role is a `.session` block with a CONNECTED / DISCONNECTED status pip. The current role has the green left-border and "live" pip.
- Tech stacks render as `stack: ["Foo", "Bar"]` literals.
- The big "stacks" block at the bottom is a fake JS object literal — `voice_realtime`, `ai_workflow`, etc.
- **Print styles override the dark theme back to B&W paper** — try `Cmd+P` and you'll get a clean printable resume. ATS-friendly because the underlying HTML is semantic (h1, ul, etc).
- There's a commented-out Hummingbird "founding engineer (loaned)" block — uncomment when ready.

### `_layouts/default.html` + `_layouts/post.html` + `blog/index.html`
Blog gets the same chrome.

- `default.html` is the new base layout. Used by `blog/index.html` and `post.html`. Replaces the original `_layouts/default.html` (which had a 850px container + horizontal nav — both removed). If anything else in the site was using `default` and depended on `<nav>`, you'll want to add it back; right now only the blog uses it.
- `post.html` extends `default`. Adds a `.lede` (from `page.description` front matter), a serif body in `<article>`, mono section headings, dark code blocks, and the giscus mount. Body type is Newsreader 17px for actual readability — the chrome is mono but the prose is not.
- `blog/index.html` lists `site.posts` with date / title / read-time / tags. The tag-filter buttons work client-side (vanilla JS, ~12 lines).

## Per-post frontmatter — optional but recommended

Posts already work as-is. For best results add **tags** and a **description** to each post's frontmatter:

```yaml
---
layout: post
title: "INSERTing Sequential Scans"
slug: inserting-sequential-scans
date: 2022-09-21
description: "One way pg_stats can ruin a query plan you thought was a sure thing."
tags: [postgres, rails, performance]
---
```

- `tags` powers the GREP filter on `/blog/`.
- `description` becomes the italic lede under the title on the post page.
- If `description` is missing the lede block hides itself — no broken layout.

Suggested tag set (used in the preview blog index):
`postgres, rails, performance, marta, open-data, atl, tutorial, war-story, callrail, reflections`

## Animations

Everything that moves respects `prefers-reduced-motion: reduce`:
- Oscilloscope on the landing — falls back to a static decorative wave.
- Caret blink on the blog index — falls back to a static dimmed block.
- Nothing else animates.

## Things deliberately removed

- The horizontal `Home / Resume / Blog` nav across the top of every page. The dial-pad on the landing replaces it. From the resume or blog, navigation is via the prompt-style links at the bottom of each page (`cd ..` etc).
- The `850px` container. Resume + blog use `960px`; landing is full-bleed.
- The light-mode CSS branch in `:root`. Site is dark-mode only now (with print falling back to B&W paper). If you want a `prefers-color-scheme: light` branch back, I can do a pass.

## Open questions (mention these in your Claude Code prompt)

1. **Hummingbird "founding engineer (loaned)" role** — commented out in `resume.html`. Uncomment when ready, fill in the real dates / copy.
2. **Grayscale bullets** — the current bullets are placeholder/impressionistic. Tell me 1–2 systems you actually owned and I'll write concrete copy.
3. **Voice AI Consulting LLC** — currently *not* in the resume. Add as a project? Add as a side-role under experience? Or stay private until contracts roll?
4. **Tags on existing posts** — none of your existing posts have a `tags:` frontmatter key. Add them so the filter works. The default `*all` view works fine without them.
5. **Did I remove anything you cared about?** — old default layout's site `<nav>`, old resume's Field Report styling (`headers`, `.tagline`, etc.). If anything else uses those classes, let me know.

## If you want to revert

The original files are in `reference/` at the project root (`index.html`, `resume.html`, `default.html`, `resume-layout.html`). Just copy them back.

— Claude (the design one)
